%LP_GetUVIntensity ?r enbart en dummy function som inte ?r f?rdig. Returnerar f?r tillf?llet en konstant 200/3;
function out = LP_GetUVIntensity(time)


out= 200/3; % Dummy value, we expect to get this is an external input to L1BP




end
